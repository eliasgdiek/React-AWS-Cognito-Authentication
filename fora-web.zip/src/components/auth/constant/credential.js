export const facebook = {
    appId: ""
};
export const google = {
    clientId: "1090681979022-m23vq8jhav18nhkn5ktg0p7i9hrr255u.apps.googleusercontent.com"
};
export const twitter = {
    consumerKey: "",
    consumerSecret: ""
};
